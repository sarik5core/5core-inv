<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MarketplacePercentage extends Model
{
    protected $fillable = ['marketplace', 'percentage'];
}