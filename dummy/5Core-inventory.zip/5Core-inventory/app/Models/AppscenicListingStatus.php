<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppscenicListingStatus extends Model
{
    protected $table = 'appscenic_listing_statuses';
    protected $fillable = ['sku', 'value'];
    protected $casts = ['value' => 'array'];
}
